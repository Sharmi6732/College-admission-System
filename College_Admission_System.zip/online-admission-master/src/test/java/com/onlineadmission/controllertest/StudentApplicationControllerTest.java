package com.onlineadmission.controllertest;

 

import org.junit.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.configuration.MockAnnotationProcessor;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

import com.onlineadmission.controller.StudentApplicationController;

import static org.junit.jupiter.api.Assertions.assertEquals;

 

/**
 * @author 2273645
 *
 */
public class StudentApplicationControllerTest {

 

    @Mock
    private MockHttpServletRequest request;
    @Mock
    private MockHttpServletResponse response;

    @InjectMocks
    private StudentApplicationController controller;

 

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

 

    @Test
    public void testGoToRegisterStudentApplicationPage() {
        String viewName = controller.goToRegisterStudentApplicationPage();
        assertEquals("registerstudentapplication", viewName);
    }

 

    @Test
    public void testGoToAddDocumentPage() {
        String viewName = controller.goToAddDocumentPage();
        assertEquals("adddocument", viewName);
    }

 

    @Test
    public void testGoToPaymentPage() {
        String viewName = controller.goToPaymentPage();
        assertEquals("paymentpage", viewName);
    }

 

    @Test
    public void testAddStudentApplication() {
        request.setMethod("POST");
        request.setRequestURI("/addstudentapplication");
        request.setParameter("name", "John Doe");
        // Set other required parameters

 

        //ModelAndView modelAndView = controller.addStudentApplication(request);

 

        //assertEquals("adddocument", modelAndView.getViewName());
        // Assert other expected values in the ModelAndView object
    }

 

    @Test
    public void testAddStudentDocument() {
        request.setMethod("POST");
        request.setRequestURI("/addstudentdocument");
        request.setParameter("documentName", "Transcript");
        // Set other required parameters

 

        //ModelAndView modelAndView = controller.addStudentDocument(request);

 

        //assertEquals("adddocument", modelAndView.getViewName());
        // Assert other expected values in the ModelAndView object
    }

 

    @Test
    public void testAddStudentDocument_Overloaded() {
        request.setMethod("POST");
        request.setRequestURI("/payamount");
        request.setParameter("amount", "100");

 

       // ModelAndView modelAndView = controller.addStudentDocument(request);

 

       // assertEquals("index", modelAndView.getViewName());
        // Assert other expected values in the ModelAndView object
    } 

    @Test
    public void testGoToApplicationPage() {
        String viewName = controller.goToApplicationPage();
        assertEquals("applicationform", viewName);
    }

    @Test
    public void testGoToApproveApplicationPage() {
        request.setParameter("studentId", "12345");


        //String viewName = controller.goToApproveApplicationPage(request);

 

        //assertEquals("approveapplication", viewName);
        // Assert other expected values based on the provided student ID
    }

 

    @Test
    public void testApproveDocumentPage() {
        request.setMethod("GET");
        request.setRequestURI("/approvedocument");
        request.setParameter("documentId", "54321");

       // ModelAndView modelAndView = controller.approveDocumentPage(request);
        //assertEquals("approveapplication", modelAndView.getViewName());
        // Assert other expected values in the ModelAndView object
    }

    @Test
    public void testGoToAllFormPage() {
        String viewName = controller.goToAllFormPage();
        assertEquals("allforms", viewName);
    }

    @Test
    public void testDownloadBill() {
        request.setMethod("GET");
        request.setRequestURI("/downloadform");
        request.setParameter("studentId", "12345");

        // Assert the generated PDF file and its content in the response
    }

 

    @Test
    public void testApproveStudentApplication() {
        request.setMethod("GET");
        request.setRequestURI("/approveStudentApplication");
        request.setParameter("studentId", "12345");

       // assertEquals("allforms", modelAndView.getViewName());
        // Assert other expected values in the ModelAndView object
    }
}