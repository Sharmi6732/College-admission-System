package com.onlineadmission.controllertest;

 

import static org.hamcrest.CoreMatchers.theInstance;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

 

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.ModelAndView;

import com.onlineadmission.controller.StudentController;
import com.onlineadmission.dao.MobileVerificationDao;
import com.onlineadmission.dao.StudentDao;
import com.onlineadmission.model.Student;

 

class StudentControllerTest {

 

	@InjectMocks
    private StudentController studentController;
    @Mock
    private StudentDao studentDao;
    @Mock
    private MobileVerificationDao mobileVerificationDao;
    @Mock
    private HttpServletRequest request;
    @Mock
    private HttpSession session;

 

    @BeforeEach
    void setUp() {
    	MockitoAnnotations.initMocks(this);
        
    }

 

    @Test
    void registerStudent_ValidStudent_ReturnsSuccessModelAndView() {
        // Arrange
        Student student = new Student();
        when(studentDao.save(student)).thenReturn(student);

 
        verify(session).setAttribute("registering-student", student);
        verify(studentDao).save(student);
       
    }

 

    // Write more tests for other methods in the StudentController class
    // Remember to cover different scenarios and edge cases

}