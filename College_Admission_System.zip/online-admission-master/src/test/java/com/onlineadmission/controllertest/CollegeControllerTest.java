package com.onlineadmission.controllertest;

 

import static org.mockito.Mockito.*;

 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

 

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.ModelAndView;

 

import com.onlineadmission.controller.CollegeController;
import com.onlineadmission.dao.*;
import com.onlineadmission.model.*;

 

class CollegeControllerTest {

    @Mock
  private CollegeDao collegeDao;
    @Mock
    private CourseDao courseDao;
    @Mock
    private CollegeAvailableCourseDao collegeAvailableCourseDao;
    @Mock
    private AppliedCollegeDao appliedCollegeDao;
    @Mock
    private StudentDao studentDao;
   @InjectMocks
    private CollegeController collegeController;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
  }


 

  @Test
  void testRegisterAdmin() {
    College college = new College();
    college.setName("Test College");
    college.setTotalSeat(100);

 

    when(collegeDao.save(college)).thenReturn(college);

 

    ModelAndView modelAndView = collegeController.registerAdmin(college);

 

    verify(collegeDao).save(college);
    // Add more assertions based on your requirements
  }

 

  @Test
  void testLoginCollege() {
    HttpServletRequest request = mock(HttpServletRequest.class);
    HttpSession session = mock(HttpSession.class);
    College college = new College();
    college.setEmail("test@example.com");
    college.setPassword("password");

 

    when(request.getSession()).thenReturn(session);
    when(collegeDao.findByEmailAndPassword("test@example.com", "password")).thenReturn(college);

 

    ModelAndView modelAndView = collegeController.loginCollege(request, "test@example.com", "password");

 

    verify(session).setAttribute("active-user", college);
    verify(session).setAttribute("user-login", "college");
    // Add more assertions based on your requirements
  }

 

  // Add more test cases for other methods in the CollegeController class

 

}