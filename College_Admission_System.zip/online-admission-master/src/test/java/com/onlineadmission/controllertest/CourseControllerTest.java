package com.onlineadmission.controllertest;

 

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

 

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.ModelAndView;

 

import com.onlineadmission.controller.CourseController;
import com.onlineadmission.dao.CourseDao;
import com.onlineadmission.model.Course;

 

public class CourseControllerTest {

    @Mock
    private CourseDao courseDao;
    @InjectMocks
    private CourseController courseController;

 

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

 

    @Test
    public void testAddCourse_Success() {
        // Arrange
        Course course = new Course();
        when(courseDao.save(course)).thenReturn(course);

 

        // Act
        ModelAndView result = courseController.addCourse(course);

 

        // Assert
        assertEquals("Course Added Successfully!", result.getModel().get("status"));
        assertEquals("index", result.getViewName());
    }

 

    @Test
    public void testAddCourse_Failure() {
        // Arrange
        Course course = new Course();
        when(courseDao.save(course)).thenReturn(null);

 

        // Act
        ModelAndView result = courseController.addCourse(course);

 

        // Assert
        assertEquals("Failed to add course.", result.getModel().get("status"));
        assertEquals("index", result.getViewName());
    }
}