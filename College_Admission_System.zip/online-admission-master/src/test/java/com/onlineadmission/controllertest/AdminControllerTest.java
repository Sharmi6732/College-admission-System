package com.onlineadmission.controllertest;

 

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

 

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

 

import com.onlineadmission.controller.AdminController;
import com.onlineadmission.dao.AdminDao;
import com.onlineadmission.model.Admin;

 

public class AdminControllerTest {

 

    @Mock
    private AdminDao adminDao;

 

    @InjectMocks
    private AdminController adminController;

 

    private HttpServletRequest request;

 

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

 

    @Test
    public void testGoToHomeDuringStart() {
        String result = adminController.goToHomeDuringStart();
        assertEquals("index", result);
    }

 

    @Test
    public void testGoToAdminLoginPage() {
        String result = adminController.goToAdminLoginPage();
        assertEquals("adminlogin", result);
    }

 

    @Test
    public void testGoToAdminRegisterPage() {
        String result = adminController.goToAdminRegisterPage();
        assertEquals("adminregister", result);
    }

 

    @Test
    public void testRegisterAdmin_Success() {
        Admin admin = new Admin();
        admin.setFirstname("John");
        when(adminDao.save(admin)).thenReturn(admin);

 

        ModelAndView mv = adminController.registerAdmin(admin, mock(Model.class));

 

        assertEquals("adminlogin", mv.getViewName());
        assertEquals("John Successfully Registered as ADMIN", mv.getModel().get("status"));
    }


    @Test
    public void testRegisterAdmin_Failure() {
        Admin admin = new Admin();
        admin.setFirstname("John");
        when(adminDao.save(admin)).thenReturn(null);

 

        ModelAndView mv = adminController.registerAdmin(admin, mock(Model.class));

 

        assertEquals("adminregister", mv.getViewName());
        assertEquals("John Failed to Registered as ADMIN", mv.getModel().get("status"));
    }

 

    @Test
    public void testLoginAdmin_Success() {
        Admin admin = new Admin();
        admin.setUsername("admin");
        admin.setPassword("password");
        when(adminDao.findByUsernameAndPassword("admin", "password")).thenReturn(admin);

    }

 

    @Test
    public void testLoginAdmin_Failure() {
        when(adminDao.findByUsernameAndPassword("admin", "password")).thenReturn(null);


        ModelAndView mv = adminController.loginAdmin(request, "admin", "password");

        assertEquals("adminlogin", mv.getViewName());
        assertEquals(" Failed to Login as ADMIN", mv.getModel().get("status"));
    }
}